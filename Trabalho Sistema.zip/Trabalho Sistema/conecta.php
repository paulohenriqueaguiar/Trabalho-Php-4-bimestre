<?php

$banco = 'trabalhosistema';
$usuario = 'root';
$senha = 'teste';

mysql_connect('localhost', $usuario, $senha);
mysql_select_db($banco);

?>